package com.example.scnuleg;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Contacts;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RequiresApi(api = Build.VERSION_CODES.N)
public class FindTask extends AppCompatActivity {
    private ListView ftLV;
    public  static List<String> name= Stream.of("帮拿个🔨  4","帮带个外卖🍱  5","帮拿个冰箱❄  20","帮找个女朋友🚺  100").collect(Collectors.toList());
    public  static List<String> task_content= Stream.of("去西二305拿个铁锤到西三205，联系人：小黑 联系微信：123456789，谢谢。","外卖块凉了，救救孩子吧","小心别被宿管发现了！","好想要一段甜甜的恋爱~").collect(Collectors.toList());
    public  static List<Integer> icons=Stream.of(R.drawable.back,R.drawable.back,R.drawable.back,R.drawable.back).collect(Collectors.toList());
    public  static List<String> button_state= Stream.of("申请接单","申请接单","申请接单","申请接单").collect(Collectors.toList());
    public  static List<Boolean> apply_enable= Stream.of(true,true,true,true).collect(Collectors.toList());
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_findtask);

        ftLV=(ListView)findViewById(R.id.lv);
        FindTask.MyBaseAdapter mAdapter = new FindTask.MyBaseAdapter();
        ftLV.setAdapter(mAdapter);
        System.out.println("check2");

        ImageButton button2 =findViewById(R.id.my_task);
        ImageButton button1 =findViewById(R.id.chat);
        ImageButton button3 =findViewById(R.id.people);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { start1();

            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start2();

            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { start3();

            }
        });

    }


    public void start1(){
        Intent intent = new Intent(FindTask.this,  Chat.class);
        startActivity(intent);

    }

    public void start2(){
        Intent intent = new Intent(FindTask.this,  MainActivity.class);
        startActivity(intent);
    }

    public void start3(){
        Intent intent = new Intent(FindTask.this,  Infor_People.class);
        startActivity(intent);
    }


    class MyBaseAdapter extends BaseAdapter {
        @Override
        public int getCount(){
            return name.size();
        }
        @Override
        public Object getItem(int position){
            return name.get(position);
        }
        @Override
        public long getItemId(int position){
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {

            View view=View.inflate(FindTask.this,R.layout.list_item,null);
            TextView mTextView=(TextView)view.findViewById(R.id.item_tv);
            mTextView.setText(name.get(position));
            ImageView imageView=(ImageView)view.findViewById(R.id.item_image);
            imageView.setBackgroundResource(icons.get(position));
            Button apply=view.findViewById(R.id.apply);
            apply.setText(button_state.get(position));
            if (apply_enable.get(position).equals(false)){
                apply.setEnabled(false);
                System.out.println("check:equls");
            }

            //查看信息按钮
            Button look=view.findViewById(R.id.look);
            look.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showNormalDialog1(task_content.get(position));
                    notifyDataSetChanged();
                }
                private void showNormalDialog1(String deatil2) {
                    AlertDialog.Builder dialog = new AlertDialog.Builder(FindTask.this);
                    dialog.setTitle("信息").setMessage(deatil2);
                    dialog.setNegativeButton("好的", null);
                    dialog.show();
                }
            });

            //申请接单按钮
            apply.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    button_state.set(position,"申请中");
                    apply_enable.set(position,false);
                    System.out.println("check:applu");

                    notifyDataSetChanged();

                    Intent intent=new Intent(FindTask.this,MainActivity.class);
                    intent.putExtra("title",name.get(position));
                    intent.putExtra("content",task_content.get(position));
                    intent.putExtra("icon",icons.get(position));
                    intent.putExtra("f_position",position);

                    startActivity(intent);
                }
            });

            return view;
        }
    }
}




