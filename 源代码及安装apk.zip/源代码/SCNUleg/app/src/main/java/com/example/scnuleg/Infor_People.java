package com.example.scnuleg;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Infor_People extends AppCompatActivity {
    private TextView id_name;
    private TextView id_domotery;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_people);

        id_name=(TextView) findViewById(R.id.name);
        id_domotery=(TextView) findViewById(R.id.address);
        ImageButton button2 =findViewById(R.id.my_task);
        ImageButton button1 =findViewById(R.id.find_task);
        ImageButton button3 =findViewById(R.id.chat);

        id_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("check111");
                set1();
            }
        });
        id_domotery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("domotery");
                set2();
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start1();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start2();
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { start3();

            }
        });
    }
    //任务栏点击
    public void start1(){

        Intent intent = new Intent(Infor_People.this,  FindTask.class);

        startActivity(intent);

    }
    public void start2(){

        Intent intent = new Intent(Infor_People.this,  MainActivity.class);

        startActivity(intent);

    }
    public void start3(){

        Intent intent = new Intent(Infor_People.this,  Chat.class);

        startActivity(intent);

    }

    public void set1(){

        Intent intent = new Intent(Infor_People.this,  set_infor.class);
        intent.putExtra("infor",id_name.getText().toString().trim());
        System.out.println("infor2:"+id_name.getText().toString());
        startActivityForResult(intent,1);
        System.out.println("check1");
    }
    public void set2(){
        System.out.println("check12345");
        Intent intent2 = new Intent(Infor_People.this,  set_infor2.class);
        intent2.putExtra("infor",id_domotery.getText().toString().trim());
        System.out.println("infor:"+id_domotery.getText().toString());
        startActivityForResult(intent2,0);
        System.out.println("check12345");

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println("checksetresult："+resultCode+"reques:"+requestCode);
        if(resultCode==1)
        {
            System.out.println("check:1");
            if (requestCode==1)
            {

                String string=data.getStringExtra("infor");
                System.out.println("check string:"+string);
                updata(string);
            }
            else if(requestCode==0)
            {
                String string=data.getStringExtra("infor2");
                System.out.println("check string2:"+string);
                updata2(string);
            }
        }

    }

    public void updata(String a){
        System.out.println("check updata");
        id_name.setText(a);
    }
    public void updata2(String a){
        System.out.println("check updata2");
        id_domotery.setText(a);
    }
}
