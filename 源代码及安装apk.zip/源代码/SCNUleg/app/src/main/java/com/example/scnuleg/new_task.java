package com.example.scnuleg;

import android.app.Application;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class new_task extends AppCompatActivity {
    private EditText title;
    private EditText content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_task);
        title=findViewById(R.id.headline);
        content=findViewById(R.id.content);
        final Button submit=findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                System.out.println("check4");
                submit();
            }
        });
        final Button cancle=findViewById(R.id.cancle);
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("check4");
                cancle();
            }
        });
    }


    public void cancle(){
        Intent intent=new Intent(new_task.this,my_release.class);
        startActivity(intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void submit(){

        FindTask.name.add(title.getText().toString().trim());
        FindTask.task_content.add(content.getText().toString().trim());
        FindTask.icons.add(R.drawable.back);
        FindTask.button_state.add("等待接单");
        FindTask.apply_enable.add(false);
//        FindTask.notifyDataSetChanged();

        Intent intent = new Intent();
        intent.putExtra("title",title.getText().toString().trim());
        intent.putExtra("content",content.getText().toString().trim());

        setResult(1,intent);
        finish();

    }

}
