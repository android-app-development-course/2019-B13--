package com.example.scnuleg;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Contacts;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class my_release extends AppCompatActivity {
    private ListView ftLV;
    static List<Integer> icons=new ArrayList<Integer>();
    static List<String> name=new ArrayList<String>();
    static List<String> deatil=new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_release);

        ftLV=(ListView)findViewById(R.id.lv);
        my_release.MyBaseAdapter mAdapter = new my_release.MyBaseAdapter();
        ftLV.setAdapter(mAdapter);
        System.out.println("check2");

        ImageButton button2 =findViewById(R.id.my_task);
        ImageButton button1 =findViewById(R.id.chat);
        ImageButton button3 =findViewById(R.id.people);
        ImageButton button4 =findViewById(R.id.find_task);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { start1();

            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start2();

            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { start3();

            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { start4();

            }
        });

        final Button goto_release=findViewById(R.id.go_to_release);

        goto_release.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("check44444");
                goto_release();
            }
        });
        final Button my_accept=findViewById(R.id.my_accept);
        my_accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("check4");
                my_accept();
            }
        });


    }


    public void start1(){
        Intent intent = new Intent(my_release.this,  Chat.class);
        startActivity(intent);

    }

    public void start2(){
        Intent intent = new Intent(my_release.this,  MainActivity.class);
        startActivity(intent);
    }

    public void start3(){
        Intent intent = new Intent(my_release.this,  Infor_People.class);
        startActivity(intent);
    }

    public void start4(){
        Intent intent = new Intent(my_release.this,  FindTask.class);
        startActivity(intent);
    }

    public void goto_release(){
        Intent intent=new Intent(my_release.this,new_task.class);
        startActivityForResult(intent,1);
    }

    public void my_accept(){
        Intent intent=new Intent(my_release.this,MainActivity.class);
        startActivity(intent);
        System.out.println("check accept");
    }

    class MyBaseAdapter extends BaseAdapter {
        @Override
        public int getCount(){
            return name.size();
        }
        @Override
        public Object getItem(int position){
            return name.get(position);
        }
        @Override
        public long getItemId(int position){
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View view=View.inflate(my_release.this,R.layout.list_item2,null);
            TextView mTextView=(TextView)view.findViewById(R.id.item_tv);
            mTextView.setText(name.get(position));
            ImageView imageView=(ImageView)view.findViewById(R.id.item_image);
            imageView.setBackgroundResource(icons.get(position));
            Button Delte_Button=view.findViewById(R.id.item_image2);
            Delte_Button.setText("取消发布");

            Delte_Button.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onClick(View v) {
                    //删除Findtask里的任务
                    FindTask.name.remove(position+4);
                    FindTask.task_content.remove(position+4);
                    FindTask.icons.remove(position+4);

                    name.remove(position);
                    icons.remove(position);
                    deatil.remove(position);
                    System.out.println("check2");
                    notifyDataSetChanged();
                }
            });

            Button look=view.findViewById(R.id.look);
            look.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showNormalDialog1(deatil.get(position));
                    notifyDataSetChanged();
                }
                private void showNormalDialog1(String deatil2) {
                    AlertDialog.Builder dialog = new AlertDialog.Builder (my_release.this);
                    dialog.setTitle ("信息").setMessage (deatil2);
                    dialog.setNegativeButton ("好的",null);
                    dialog.show ();
                }

            });
            return view;
        }


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==1)
        {
            if (requestCode==1)
            {
                String title=data.getStringExtra("title");
                String content=data.getStringExtra("content");
                icons.add(R.drawable.back);
                name.add(title);
                deatil.add(content);
                Intent intent3=new Intent(my_release.this,my_release.class);
                startActivity(intent3);

            }

        }

    }
}




