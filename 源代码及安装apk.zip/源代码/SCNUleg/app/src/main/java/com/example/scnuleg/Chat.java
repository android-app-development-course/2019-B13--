package com.example.scnuleg;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Chat extends AppCompatActivity {
    private SideBar indexBar;
    /**
     * 显示字母的TextView
     */
    private TextView textViewDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        indexBar = (SideBar) findViewById(R.id.sideBar);
        textViewDialog = (TextView) findViewById(R.id.textViewDialog);
        indexBar.setTextViewDialog(textViewDialog);

        ImageButton button2 =findViewById(R.id.my_task);
        ImageButton button1 =findViewById(R.id.find_task);
        ImageButton button3 =findViewById(R.id.people);
        button1.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {

                                           start1();

                                       }
                                   }

        );
        button2.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           start2();

                                       }
                                   }

        );
        button3.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           start3();

                                       }
                                   }

        );



    }

    public void start1(){

        Intent intent = new Intent(Chat.this,  FindTask.class);

        startActivity(intent);

    }

    public void start2(){

        Intent intent = new Intent(Chat.this,  MainActivity.class);

        startActivity(intent);

    }
    public void start3(){

        Intent intent = new Intent(Chat.this,  Infor_People.class);

        startActivity(intent);

    }



}
