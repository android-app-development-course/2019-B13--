package com.example.scnuleg;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class set_infor2 extends AppCompatActivity {
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.out.println("check2");
        setContentView(R.layout.set_infor);

        Intent intent=getIntent();
        String infor=intent.getStringExtra("infor");

        Button button=findViewById(R.id.save_infor);
        editText=findViewById(R.id.input_infor);
        editText.setText(infor);
        System.out.println("check4,infor:"+infor);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }


        });
    }

    public void save() {
        Intent intent2=new Intent();

        intent2.putExtra("infor2",editText.getText().toString().trim());
        System.out.println("check-infor");

        setResult(1,intent2);

        System.out.println("check3intent2:"+intent2.getStringExtra("infor2"));
        finish();

    }
}
