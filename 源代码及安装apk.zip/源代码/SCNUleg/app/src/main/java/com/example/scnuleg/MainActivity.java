package com.example.scnuleg;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MainActivity extends AppCompatActivity {
    private ListView ftLV;
    private List list;
    static List<Integer> icons=new ArrayList<Integer>();
    static List<String> name=new ArrayList<String>();
    static List<String> deatil=new ArrayList<String>();
    static List<Integer> f_position=new ArrayList<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_accept);

        list = new ArrayList();
        ftLV = (ListView) findViewById(R.id.lv);
        MainActivity.MyBaseAdapter mAdapter = new MainActivity.MyBaseAdapter();
        ftLV.setAdapter(mAdapter);

        ImageButton button = findViewById(R.id.find_task);
        ImageButton button2 = findViewById(R.id.chat);
        ImageButton button3 = findViewById(R.id.people);
        Button my_release=findViewById(R.id.my_Release);
//        Button my_release=findViewById(R.id.my_Release);
        System.out.println("check0.1");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start();

            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start2();
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start3();
            }
        });
        my_release.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                my_release();
            }
        });
//        my_release.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                my_release();
//            }
//        });


        //接收findtask传入的数值
        Intent f_intent = getIntent();
        String f_task_name = f_intent.getStringExtra("title");
        int f_task_icon = f_intent.getIntExtra("icon", 0);
        String detailed = f_intent.getStringExtra("content");
        if (f_task_name!=null){
            name.add(f_task_name);
            icons.add(f_task_icon);
            deatil.add(detailed);
            f_position.add(f_intent.getIntExtra("f_position",0));
            mAdapter.notifyDataSetChanged();
        }




    }

    public void start() {
        System.out.println("check0.3");
        Intent intent1 = new Intent(MainActivity.this, FindTask.class);
        System.out.println("check0.33");
        startActivity(intent1);
        System.out.println("check0.344444");
    }
    public void start2() {

        Intent intent2 = new Intent(MainActivity.this, Chat.class);

        startActivity(intent2);
    }
    public void start3() {

        Intent intent3 = new Intent(MainActivity.this, Infor_People.class);

        startActivity(intent3);

    }


    class MyBaseAdapter extends BaseAdapter {
        @Override
        public int getCount(){
            return name.size();
        }
        @Override
        public Object getItem(int position){
            return name.get(position);
        }
        @Override
        public long getItemId(int position){
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View view=View.inflate(MainActivity.this,R.layout.list_item2,null);
            TextView mTextView=(TextView)view.findViewById(R.id.item_tv);
            mTextView.setText(name.get(position));
            ImageView imageView=(ImageView)view.findViewById(R.id.item_image);
            imageView.setBackgroundResource(icons.get(position));
            Button Delte_Button=view.findViewById(R.id.item_image2);
            Delte_Button.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onClick(View v) {
                    FindTask.button_state.set(f_position.get(position),"申请接单");
                    FindTask.apply_enable.set(f_position.get(position),true);
                    name.remove(position);
                    icons.remove(position);
                    deatil.remove(position);
                    f_position.remove(position);
                    notifyDataSetChanged();
                    System.out.println("check:delet");


                }
            });
            Button look=view.findViewById(R.id.look);
            look.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showNormalDialog1(deatil.get(position));
                    notifyDataSetChanged();
                }
                private void showNormalDialog1(String deatil2) {
                    AlertDialog.Builder dialog = new AlertDialog.Builder (MainActivity.this);
                    dialog.setTitle ("信息").setMessage (deatil2);
                    dialog.setNegativeButton ("好的",null);
                    dialog.show ();
                }

            });
            return view;
        }


    }


    public void my_accept(){

    }

    public void my_release(){
        System.out.println("check_myrelease");
        Intent intent=new Intent(MainActivity.this,my_release.class);
        startActivity(intent);
        System.out.println("check2");


    }
}
